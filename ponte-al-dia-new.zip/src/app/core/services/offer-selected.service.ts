import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OfferSelectedService {
  offer: any;
  offerBank: any;
  state: any;
  de: any;
  nitCompany: any;
  numberAccount: any;
  nameCompany: any;
  nameBank: any;
  constructor() { }
}