export interface User {
    idUsuario: number;
    tipoDocumento: number;
    documento: string;
    nombre: string;
    apellido: string;
    correo: string;
    ingreso: number;
    ocupacion: string;
    fechaExpDocumento: string;
    phone: string;
    codEstado: number;
    idUserOkta: string;
}