import { ResponseObject } from './responseObject.model';

export interface CustomerDebts {
    responseObject: ResponseObject;
    success: boolean;
    error: null;
}
